#include <iostream>
#include <vector>
#include "Account.h"
#include "Customer.h"
#include "Employee.h"
#include "Manager.h"
#include "Bank.h"


int main()
{

	Manager manager = Manager("ali", "mkhani", "alimkhani", "1377", "2110943513", "15.11.77");
	Bank bank = Bank(&manager);
	bool con1 = true;
	bool con2 = true;
	bool con2_1 = true;
	bool con3 = true;
	bool con3_1 = true;
	string skipClosing;

	while (con1)
	{
		int item = 0;
		system("CLS");
		cout << "1- Employee\n"
			<< "2- Customer\n"
			<< "3- Quit\n";
		cin >> item;
		switch (item)
		{
		case 1:
			con2 = true;
			while (con2)
			{
				system("CLS");
				cout << "enter the username" << endl;
				string username;
				cin >> username;
				cout << "enter the password" << endl;
				string password;
				cin >> password;
				Employee* employee;
				try
				{
					employee = bank.LogEmployee(username, password);
					con2_1 = true;
				}
				catch (const std::invalid_argument& ex)
				{
					cout << ex.what();
					cout << endl << "enter a key to back to the main menu" << endl;
					cin >> skipClosing;
					con2 = false;
					break;
				}

				if (bank.CheckManager(employee))
				{
					while (con2_1)
					{
						system("CLS");

						cout << employee->GetUserName() << endl;
						cout << "1- Take a few hours off\n"
							<< "2- Take over time\n"
							<< "3- show personal information\n"
							<< "4- show customer information with national number\n"
							<< "5- create account for customer\n"
							<< "6- delete an account from customer\n"
							<< "7- show employee personal information\n"
							<< "8- add an employee\n"
							<< "9- delete an employee\n"
							<< "10- quit\n";
						cin >> item;
						switch (item)
						{
						case 1:
						{
							system("CLS");
							cout << "Take a few hours off" << endl;
							cout << "off hours:" + to_string(employee->GetOffHours()) << endl;
							cout << "How many hours do you want to take off?" << endl;
							int hours;
							cin >> hours;
							string message = bank.TakeOffHoursForEmployee(hours, employee);
							cout << message;
							cin >> skipClosing;
							break;
						}
						case 2:
						{
							system("CLS");
							cout << "Take over time" << endl;
							cout << "over time hours:" + to_string(employee->GetOvertimeHours()) << endl;
							cout << "How many hours do you want to take over time?" << endl;
							int hours;
							cin >> hours;
							string message = bank.TakeOverTimeForEmployee(hours, employee);
							cout << message;
							cin >> skipClosing;

							break;
						}
						case 3:
						{
							system("CLS");
							cout << "show personal information" << endl;
							cout << employee->Print();
							cin >> skipClosing;
							break;
						}
						case 4:
						{
							system("CLS");
							cout << "show customer information with national number" << endl;
							cout << "insert customer national number: ";
							string nationalCode;
							cin >> nationalCode;
							try
							{
								cout << employee->PrintCustomerInfo(nationalCode, bank.GetCustomers());
							}
							catch (const std::exception& e)
							{
								cout << e.what();
							}
							cin >> skipClosing;
							break;
						}
						case 5:
						{
							system("CLS");
							cout << "create account for customer" << endl;
							cout << "insert customer username: " << endl;
							string username;
							cin >> username;
							Customer* customer;
							if (!bank.ExistCustomer(username))
							{
								cout << "the customer does not exist!" << endl << "register customer" << endl;
								cout << "insert first name:" << endl;
								string firstName;
								cin >> firstName;
								cout << "insert last name:" << endl;
								string lastName;
								cin >> lastName;
								cout << "insert user name:" << endl;
								string userName;
								cin >> userName;
								cout << "insert password:" << endl;
								string password;
								cin >> password;
								cout << "insert national code:" << endl;
								string nationalCode;
								cin >> nationalCode;
								cout << "insert birthdate:" << endl;
								string birthDate;
								cin >> birthDate;
								customer = new Customer(firstName, lastName, userName,
									password, nationalCode, birthDate);
								employee->AddCustomer(customer, bank.GetCustomers());
								cout << "the customer added" << endl;
							}
							else
							{
								customer = bank.GetCustomerByUserName(username);
							}
							cout << "create account:" << endl;
							cout << "insert balance:" << endl;
							float balance;
							cin >> balance;
							Account* account = new Account(customer->GetNationalCode(), balance);
							try
							{
								employee->CreateAccount(customer, account);
								cout << "done!" << endl;
							}
							catch (const std::exception& e)
							{
								cout << e.what() << endl;
							}
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						case 6:
						{
							system("CLS");
							cout << "delete an account from customer" << endl;
							cout << "insert customer national number: ";
							string username;
							cin >> username;
							Customer* customer;
							if (!bank.ExistCustomer(username))
							{
								cout << "the customer does not exist!" << endl;
							}
							else
							{
								customer = bank.GetCustomerByUserName(username);
								auto accounts = customer->GetAccounts();
								if (accounts.size() == 0)
								{
									cout << "the customer does not have any account" << endl;
									cout << "enter a key to back";
									cin >> skipClosing;
									break;
								}
								cout << "accounts: " << endl;
								for (int i = 0; i < accounts.size(); i++)
								{
									cout << accounts[i]->Print() << endl;
								}

								cout << "insert account id" << endl;
								int id;
								cin >> id;
								Account* account = customer->GetAccountById(id);
								if (account)
								{
									employee->DeleteAccount(customer, account);
								}
								else
								{
									cout << "the account does not exist!" << endl;
								}
							}
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						case 7:
						{
							system("CLS");
							cout << "show employee information" << endl;
							cout << "insert employee personal id: ";
							int perId;
							cin >> perId;
							try
							{
								cout << manager.PrintEmployeeInfo(perId, bank.GetEmployees()) << endl;
							}
							catch (const std::exception& e)
							{
								cout << e.what() << endl;
							}
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						case 8:
						{
							system("CLS");
							cout << "add an employee" << endl;
							cout << "insert first name:" << endl;
							string firstName;
							cin >> firstName;
							cout << "insert last name:" << endl;
							string lastName;
							cin >> lastName;
							cout << "insert user name:" << endl;
							string userName;
							cin >> userName;
							cout << "insert password:" << endl;
							string password;
							cin >> password;
							cout << "insert national code:" << endl;
							string nationalCode;
							cin >> nationalCode;
							cout << "insert birthdate:" << endl;
							string birthDate;
							cin >> birthDate;
							Employee* employee = new Employee(firstName, lastName, userName,
								password, nationalCode, birthDate);
							manager.AddEmployee(employee, bank.GetEmployees());
							cout << "the employee added" << endl;
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						case 9:
						{
							system("CLS");
							cout << "delete an employee" << endl;
							for (int i = 0; i < bank.GetEmployees()->size(); i++)
							{
								if (!bank.CheckManager(bank.GetEmployees()[0].at(i)))
								{
									cout << bank.GetEmployees()[0].at(i)->Print() << endl;
								}
							}
							cout << "insert employee personal id: ";
							int perId;
							cin >> perId;
							auto em = bank.GetEmployeeByPersonalId(perId);
							if (em)
							{
								manager.DeleteEmployee(perId, bank.GetEmployees());
								cout << "Done! enter a key to back";
								cin >> skipClosing;
								break;
							}
							else
							{
								cout << "the employee dose not exist" << endl;
								cout << "enter a key to back";
								cin >> skipClosing;
								break;
							}

						}
						case 10:
						{
							con2 = false;
							con2_1 = false;
							break;
						}

						default:
							break;
						}
					}

				}
				else
				{
					while (con2_1)
					{
						system("CLS");

						cout << employee->GetUserName() << endl;
						cout << "1- Take a few hours off\n"
							<< "2- Take over time\n"
							<< "3- show personal information\n"
							<< "4- show customer information with national number\n"
							<< "5- create account for customer\n"
							<< "6- delete an account from customer\n"
							<< "7- quit\n";
						cin >> item;
						switch (item)
						{
						case 1:
						{
							system("CLS");
							cout << "Take a few hours off" << endl;
							cout << "off hours:" + to_string(employee->GetOffHours()) << endl;
							cout << "How many hours do you want to take off?" << endl;
							int hours;
							cin >> hours;
							string message = bank.TakeOffHoursForEmployee(hours, employee);
							cout << message;
							cin >> skipClosing;
							break;
						}
						case 2:
						{
							system("CLS");
							cout << "Take over time" << endl;
							cout << "over time hours:" + to_string(employee->GetOvertimeHours()) << endl;
							cout << "How many hours do you want to take over time?" << endl;
							int hours;
							cin >> hours;
							string message = bank.TakeOverTimeForEmployee(hours, employee);
							cout << message;
							cin >> skipClosing;

							break;
						}
						case 3:
						{
							system("CLS");
							cout << "show personal information" << endl;
							cout << employee->Print();
							cin >> skipClosing;
							break;
						}
						case 4:
						{
							system("CLS");
							cout << "show customer information with national number" << endl;
							cout << "insert customer national number: ";
							string nationalCode;
							cin >> nationalCode;
							try
							{
								cout << employee->PrintCustomerInfo(nationalCode, bank.GetCustomers());
							}
							catch (const std::exception& e)
							{
								cout << e.what();
							}
							cin >> skipClosing;
							break;
						}
						case 5:
						{
							system("CLS");
							cout << "create account for customer" << endl;
							cout << "insert customer username: " << endl;
							string username;
							cin >> username;
							Customer* customer;
							if (!bank.ExistCustomer(username))
							{
								cout << "the customer does not exist!" << endl << "register customer" << endl;
								cout << "insert first name:" << endl;
								string firstName;
								cin >> firstName;
								cout << "insert last name:" << endl;
								string lastName;
								cin >> lastName;
								cout << "insert user name:" << endl;
								string userName;
								cin >> userName;
								cout << "insert password:" << endl;
								string password;
								cin >> password;
								cout << "insert national code:" << endl;
								string nationalCode;
								cin >> nationalCode;
								cout << "insert birthdate:" << endl;
								string birthDate;
								cin >> birthDate;
								customer = new Customer(firstName, lastName, userName,
									password, nationalCode, birthDate);
								employee->AddCustomer(customer, bank.GetCustomers());
								cout << "the customer added" << endl;
							}
							else
							{
								customer = bank.GetCustomerByUserName(username);
							}
							cout << "create account:" << endl;
							cout << "insert balance:" << endl;
							float balance;
							cin >> balance;
							Account* account = new Account(customer->GetNationalCode(), balance);
							try
							{
								employee->CreateAccount(customer, account);
								cout << "done!" << endl;
							}
							catch (const std::exception& e)
							{
								cout << e.what() << endl;
							}
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						case 6:
						{
							system("CLS");
							cout << "delete an account from customer" << endl;
							cout << "insert customer national number: ";
							string username;
							cin >> username;
							Customer* customer;
							if (!bank.ExistCustomer(username))
							{
								cout << "the customer does not exist!" << endl;
							}
							else
							{
								customer = bank.GetCustomerByUserName(username);
								auto accounts = customer->GetAccounts();
								if (accounts.size() == 0)
								{
									cout << "the customer does not have any account" << endl;
									cout << "enter a key to back";
									cin >> skipClosing;
									break;
								}
								cout << "accounts: " << endl;
								for (int i = 0; i < accounts.size(); i++)
								{
									cout << accounts[i]->Print() << endl;
								}

								cout << "insert account id" << endl;
								int id;
								cin >> id;
								Account* account = customer->GetAccountById(id);
								if (account)
								{
									employee->DeleteAccount(customer, account);
								}
								else
								{
									cout << "the account does not exist!" << endl;
								}
							}
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						case 7:
						{
							con2 = false;
							con2_1 = false;
							break;
						}

						default:
							break;
						}
					}
				}

			}
			break;
		case 2:
		{
			con3 = true;
			while (con3)
			{
				system("CLS");
				cout << "enter the username" << endl;
				string username;
				cin >> username;
				cout << "enter the password" << endl;
				string password;
				cin >> password;
				Customer* customer;
				try
				{
					customer = bank.LogCustomer(username, password);
					con3_1 = true;

				}
				catch (const std::invalid_argument& ex)
				{

					cout << ex.what() << endl;
					cin >> skipClosing;
					con3 = false;
					break;
				}
				while (con3_1)
				{
					system("CLS");
					//con2_1 = true;

					cout << customer->GetUserName() << endl;
					cout << "1- Increase account balance\n"
						<< "2- withdrawal\n"
						<< "3- show personal information\n"
						<< "4- quit\n";
					cin >> item;
					switch (item)
					{
					case 1:
					{
						system("CLS");
						cout << "Increase account balance:" << endl;
						auto accounts = customer->GetAccounts();
						if (accounts.size() == 0)
						{
							cout << "the customer does not have any account" << endl;
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						cout << "accounts: " << endl;
						for (int i = 0; i < accounts.size(); i++)
						{
							cout << accounts[i]->Print() << endl;
						}

						cout << "insert account id" << endl;
						int id;
						cin >> id;
						Account* account = customer->GetAccountById(id);
						if (account)
						{
							cout << "enter the value to increase balance: " << endl;
							float value;
							cin >> value;
							account->IncreaseBalance(value);
							cout << "Done! the new balance of this account: " + to_string(account->GetBalance()) << endl;
						}
						else
						{
							cout << "the account does not exist!" << endl;
						}
						cout << "enter a key to back";
						cin >> skipClosing;
						break;
					}
					case 2:
					{
						system("CLS");
						cout << "withdrawal:" << endl;
						auto accounts = customer->GetAccounts();
						if (accounts.size() == 0)
						{
							cout << "the customer does not have any account" << endl;
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						cout << "accounts: " << endl;
						for (int i = 0; i < accounts.size(); i++)
						{
							cout << accounts[i]->Print() << endl;
						}

						cout << "insert account id" << endl;
						int id;
						cin >> id;
						Account* account = customer->GetAccountById(id);
						if (account)
						{
							cout << "enter the value to withdrawal: " << endl;
							float value;
							cin >> value;
							try
							{
								account->DecreaseBalance(value);
								cout << "Done! the new balance of this account: " + to_string(account->GetBalance()) << endl;
							}
							catch (const std::invalid_argument& e)
							{
								cout << e.what() << endl;
								cout << "enter a key to back";
								cin >> skipClosing;
								break;
							}
						}
						else
						{
							cout << "the account does not exist!" << endl;
						}
						cout << "enter a key to back";
						cin >> skipClosing;
						break;
					}
					case 3:
					{
						system("CLS");
						cout << "show personal information:" << endl;
						cout << customer->Print() << endl;
						cout << "enter 1 to show accounts or enter another key to exit";
						cin >> skipClosing;
						if (skipClosing == "1")
						{
							auto accounts = customer->GetAccounts();
							if (accounts.size() == 0)
							{
								cout << "the customer does not have any account" << endl;
								cout << "enter a key to back";
								cin >> skipClosing;
								break;
							}
							cout << "accounts: " << endl;
							for (int i = 0; i < accounts.size(); i++)
							{
								cout << accounts[i]->Print() << endl;
							}
							cout << "enter a key to back";
							cin >> skipClosing;
							break;
						}
						break;
					}

					case 4:
					{
						con3 = false;
						con3_1 = false;
						break;
					}
					default:
						con3_1 = false;
						break;
					}
				}
			}
		}
		break;
		case 3:
		{
			con1 = false;
			break;
		}
		default:
			con1 = false;
			break;
		}
		getchar();
	}

	return 0;
}






