
class Person
{
public:
	Person(string firstName, string lastName,
		string userName, string password,
		string nationalCode, string BirthDate);

	string GetUserName() { return this->userName; };
	string GetNationalCode() { return this->nationalCode; };
	string GetFirstName() { return this->nationalCode; };
	string GetLastName() { return this->nationalCode; };


	bool IsLogged() { return logged; }
	bool LogIn(string password);
	void LogOut() { logged = false; }

protected:
	virtual string Print();
	string firstName;
	string lastName;
	string userName;
	string password;
	string nationalCode;
	string birthDate;

	bool logged;
};

Person::Person(string firstName, string lastName,
	string userName, string password,
	string nationalCode, string birthDate)
{
	this->firstName = firstName;
	this->lastName = lastName;
	this->userName = userName;
	this->password = password;
	this->nationalCode = nationalCode;
	this->birthDate = birthDate;
}

string Person::Print()
{
	string res = "full name: " + firstName + " " + lastName + "\n"
		+ "user name: " + userName + "\n"
		+ "birth date: " + birthDate + "\n" +
		"national code: " + nationalCode;
	return res;
}
bool Person::LogIn(string password)
{
	if (this->password == password)
	{
		logged = true;
		return true;
	}
	return false;
}





















//bool IsCorrectUserNamePassword(string userName, string password);
//bool IsCorrectPassword( string password);


//bool Person::IsCorrectUserNamePassword(string userName,string password)
//{
//	if (this->userName == userName && this->password == password)
//	{
//		return true;
//	}
//	return false;
//}

//bool Person::IsCorrectPassword(string password)
//{
//	if (this->password == password)
//	{
//		return true;
//	}
//	return false;
//}
