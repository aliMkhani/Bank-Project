#include <string>
using namespace std;

static int uniqeId = 0;
static int uniqeAccountNumber = 1000;

class Account
{
	friend class Employee;
public:
	Account();
	Account(string CustomerNationalCode, float balance);
	~Account();
	int GetAccountId() { return Id; };
	void IncreaseBalance(float balance) { this->balance += balance; };
	void DecreaseBalance(float balance);
	float GetBalance() { return balance; }
	string Print();
private:
	string customerNationalCode;
	int Id;
	float balance;
	string accountOpeningDate;
	bool activation;
	int accountNumber;
};


Account::Account()
{
	Id = uniqeId;
	uniqeId++;
	accountNumber = uniqeAccountNumber;
	uniqeAccountNumber++;
	activation = true;
}

Account::Account(string customerNationalCode, float balance)
{
	Id = uniqeId;
	uniqeId++;
	accountNumber = uniqeAccountNumber;
	uniqeAccountNumber++;
	activation = true;
	this->customerNationalCode = customerNationalCode;
	this->balance = balance;
	accountOpeningDate = "now";
}

Account::~Account()
{
}

void Account::DecreaseBalance(float balance)
{
	if (this->balance >= balance)
	{
		this->balance -= balance;
		return;
	}
	throw std::invalid_argument("the balance is not enough!");

}

inline string Account::Print()
{
	return "id: " + to_string(Id) + "\n"
		+ "account number: " + to_string(accountNumber) + "\n"
		+ "customer national Code : " + customerNationalCode + "\n"
		+ "balance: " + to_string(balance) + "\n";
	+"activition: " + to_string(activation) + "\n";
	+"account opening date: " + accountOpeningDate + "\n";
}

