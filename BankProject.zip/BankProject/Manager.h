


class Manager : public Employee
{
public:
	Manager(string firstName, string lastName,
		string userName, string password,
		string nationalCode, string birthDate);
	~Manager();
	void AddEmployee(Employee* employee, vector<Employee*>* employees);
	void DeleteEmployee(int personalId, vector<Employee*>* employees);
	string PrintEmployeeInfo(int personalId, vector<Employee*>* employees);


private:
};

Manager::Manager(string firstName, string lastName,
	string userName, string password,
	string nationalCode, string birthDate)
	: Employee(firstName, lastName,
		userName, password,
		nationalCode, birthDate)
{
}


Manager::~Manager()
{
}

string Manager::PrintEmployeeInfo(int personalId, vector<Employee*>* employees)
{
	Employee* e = 0;
	for (int i = 0; i < employees->size(); i++)
	{
		if (employees->at(i)->GetPersonalId() == personalId)
		{
			e = employees->at(i);
		}
	}
	if (e)
	{
		return e->Print();
	}
	throw std::invalid_argument("the employee does not exist");
}

void Manager::AddEmployee(Employee* employee, vector<Employee*>* employees)
{
	employees->push_back(employee);
}

void Manager::DeleteEmployee(int personalId, vector<Employee*>* employees)
{
	Employee* e = 0;
	vector<Employee*>* newEmployees = new vector<Employee*>();

	for (int i = 0; i < employees->size(); i++)
	{
		if (employees->at(i)->GetPersonalId() == personalId)
		{
			e = employees->at(i);
			continue;
		}
		else
		{
			newEmployees->push_back(employees->at(i));
		}
	}
	if (!e)
	{
		throw new exception("the employee does not exist");
	}
	employees = newEmployees;
}

