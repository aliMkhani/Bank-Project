#include <string>

class Bank
{
public:
	Bank(Manager* manager);
	//Bank();
	~Bank();
	Customer* GetCustomerByUserName(string userName);
	bool ExistCustomer(string userName);
	Employee* GetEmployeeByUserName(string userName);
	Employee* GetEmployeeByPersonalId(int personalId);
	vector<Customer*>* GetCustomers() { return customers; };
	vector<Employee*>* GetEmployees() { return employees; };
	string TakeOffHoursForEmployee(int offHours, Employee* employee);
	string TakeOverTimeForEmployee(int overTime, Employee* employee);
	Customer* LogCustomer(string userName, string password);
	Employee* LogEmployee(string userName, string password);
	bool CheckManager(Employee* employee);
private:
	vector<Customer*>* customers;
	vector<Employee*>* employees;
	Manager* manager;
};

Bank::Bank(Manager* manager)
{
	customers = new vector<Customer*>();
	employees = new vector<Employee*>();
	this->manager = manager;
	employees->push_back(manager);
}


Bank::~Bank()
{
}

Employee* Bank::GetEmployeeByUserName(string userName)
{
	for (int i = 0; i < this->employees->size(); i++)
	{
		if (employees->at(i)->GetUserName() == userName)
		{
			return employees->at(i);
		}
	}
	return 0;
}

inline Employee* Bank::GetEmployeeByPersonalId(int personalId)
{
	for (int i = 0; i < this->employees->size(); i++)
	{
		if (employees->at(i)->GetPersonalId() == personalId)
		{
			return employees->at(i);
		}
	}
	return 0;
}


Customer* Bank::GetCustomerByUserName(string userName)
{
	for (int i = 0; i < this->customers->size(); i++)
	{
		if (customers->at(i)->GetUserName() == userName)
		{
			return customers->at(i);
		}
	}
	return 0;
}

bool Bank::ExistCustomer(string userName)
{
	for (int i = 0; i < customers->size(); i++)
	{
		if (customers->at(i)->GetUserName() == userName)
		{
			return true;
		}
	}
	return false;
}

string Bank::TakeOffHoursForEmployee(int offHours, Employee* employee)
{
	auto a = employee->GetAllowedOffHours(15);
	if (a > 0)
	{
		employee->TakeOffHour(offHours);

		a = employee->GetAllowedOffHours(15);
		if (a < 0)
		{
			employee->DecreseSalary((employee->GetOffHours() - 15) * 100000);
			return "You have taken more than 15 hours off\nYour new salary: " + to_string(employee->GetSalary());
		}
		return "you can take " + to_string(a) + " off hours";
	}
	else
	{
		employee->TakeOffHour(offHours);
		employee->DecreseSalary(offHours * 100000);
		return "You have taken more than 15 hours off\nYour new salary: " + to_string(employee->GetSalary());
	}
}

string Bank::TakeOverTimeForEmployee(int overTime, Employee* employee)
{
	auto a = employee->GetAllowedOverTimeHours(12);
	if (a > 0)
	{
		if (employee->GetOvertimeHours() + overTime > 12)
		{
			return "you cant take over time more than 12 hours , over time houres:" + to_string(employee->GetOvertimeHours());
		}
		employee->TakeOvertimeHours(overTime);
		employee->IncreaseSalary(overTime * 120000);
		return "your new salary:" + to_string(employee->GetSalary());
	}
	else
	{
		return "you cant take over time more than 12 hours , over time houres:" + to_string(employee->GetOvertimeHours());
	}

}

inline Customer* Bank::LogCustomer(string userName, string password)
{
	auto c = GetCustomerByUserName(userName);
	if (c)
	{
		bool logged = c->LogIn(password);
		if (!logged)
		{
			throw new exception("the password is wrong!");
		}
		return c;
	}
	throw std::invalid_argument("the customer does not exist!");
}

inline Employee* Bank::LogEmployee(string userName, string password)
{
	Employee* e = GetEmployeeByUserName(userName);
	if (e)
	{
		bool logged = e->LogIn(password);
		if (!logged)
		{
			throw std::invalid_argument("the password is wrong!");
		}
		return e;
	}
	throw std::invalid_argument("the Employee does not exist!");
}

inline bool Bank::CheckManager(Employee* employee)
{
	if (this->manager == employee)
	{
		return true;
	}
	return false;
}


