#include "Person.h"
#include <vector>
#include <string>


class Customer : public Person
{
	friend class Employee;
public:
	Customer(string firstName, string lastName,
		string userName, string password,
		string nationalCode, string birthDate);
	~Customer();
	string Print();
	Account* GetAccountById(int accountId);
	vector<Account*> GetAccounts() { return this->accounts; };
	void AddAccount(Account* account) { this->accounts.push_back(account); };
	void IncreaseBalance(int accountId, float balance);
	void DecreaseBalance(int accountId, float balance);
private:
	vector<Account*> accounts;
};

Customer::Customer(string firstName, string lastName,
	string userName, string password,
	string nationalCode, string birthDate)
	: Person(firstName, lastName,
		userName, password,
		nationalCode, birthDate)
{
}


Customer::~Customer()
{
}

string Customer::Print()
{
	string res = Person::Print() + "\n account count: ";
	float totalBalance = 0;
	for (int i = 0; i < accounts.size(); i++)
	{
		totalBalance += accounts[i]->GetBalance();
	}
	res += accounts.size() + " total balance: ";
	res += totalBalance;
	return Person::Print() + "\n account count: " + to_string(accounts.size())
		+ " total balance: " + to_string(totalBalance);
}


Account* Customer::GetAccountById(int accountId)
{
	for (int i = 0; i < accounts.size(); i++)
	{
		if (accounts[i]->GetAccountId() == accountId)
		{
			return accounts[i];
		}
	}
	return 0;
}

void Customer::IncreaseBalance(int accountId, float balance)
{
	if (this->IsLogged())
	{
		Account* account = this->GetAccountById(accountId);
		if (account)
		{
			account->IncreaseBalance(balance);
			return;
		}
		else
		{
			throw new exception("The account does not exist.");
			return;
		}
	}
	else
	{
		throw new exception("The customer is not logged in");
		return;
	}
}

void Customer::DecreaseBalance(int accountId, float balance)
{
	if (this->IsLogged())
	{
		Account* account = this->GetAccountById(accountId);
		if (account)
		{
			try
			{
				account->DecreaseBalance(balance);
			}
			catch (const std::exception& ex)
			{
				////////?
				throw ex;
			}
			return;
		}
		else
		{
			throw new exception("The account does not exist.");
			return;
		}
	}
	else
	{
		throw new exception("The customer is not logged in");
		return;
	}
}

