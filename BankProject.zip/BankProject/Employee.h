#include <string>
using namespace std;

static int uniqeSetPersonalId = 100;

class Employee : public Person
{
public:
	Employee(string firstName, string lastName,
		string userName, string password,
		string nationalCode, string birthDate);
	~Employee();
	int GetOffHours() { return offHours; };
	int GetOvertimeHours() { return overTimeHours; };
	void TakeOffHour(int offHours) { this->offHours += offHours; };
	void DecreseSalary(float x) { this->defaultSalary -= x; };
	void IncreaseSalary(float x) { this->defaultSalary += x; };
	float GetSalary() { return defaultSalary; };
	int GetAllowedOffHours(int allowedOffHours) { return allowedOffHours - offHours; };
	void TakeOvertimeHours(int OvertimeHours) { overTimeHours += OvertimeHours; };
	int GetAllowedOverTimeHours(int allowedOvertimeHours) { return allowedOvertimeHours - overTimeHours; };
	void CreateAccount(Customer* customer, Account* account);
	void AddCustomer(Customer* customer, vector<Customer*>* customers) { customers[0].push_back(customer);};
	int GetPersonalId() { return personalId; };
	void ActiveAccount(Account* account);
	void DeActiveAccount(Account* account);
	void DeleteAccount(Customer* customer, Account* account);
	string PrintCustomerInfo(string nationalCode, vector<Customer*>* customers);
	string Print();

protected:
	int personalId;
	float defaultSalary = 2000000;
	int offHours = 0;
	int overTimeHours = 0;
};

Employee::Employee(string firstName, string lastName,
	string userName, string password,
	string nationalCode, string birthDate)
	: Person(firstName, lastName,
		userName, password,
		nationalCode, birthDate)
{
	personalId = uniqeSetPersonalId;
	uniqeSetPersonalId++;
}

Employee::~Employee()
{
}

void Employee::CreateAccount(Customer* customer, Account* account)
{
	if (account->GetBalance() < 50000)
	{
		throw std::invalid_argument("the balance must be >= 50000");
	}
	else
	{
		customer->AddAccount(account);
	}
}

string Employee::PrintCustomerInfo(string nationalCode, vector<Customer*>* customers)
{
	//////////////////////aya customer vojood dare? inja check konam?
	Customer* c = 0;
	for (int i = 0; i < customers->size(); i++)
	{
		if (customers->at(i)->GetNationalCode() == nationalCode)
		{
			c = customers->at(i);
		}
	}
	if (c)
	{
		//print info
		return c->Print();
	}
	throw std::invalid_argument("the customer does not exist!");
}

string Employee::Print()
{
	return Person::Print() + "\n"
		+ "personal id:" + to_string(personalId) + "\n"
		+ "salary: " + to_string(defaultSalary) + "\n"
		+ "off hours: " + to_string(offHours) + "\n"
		+ "overtime hours: " + to_string(overTimeHours);
}




void Employee::ActiveAccount(Account* account)
{
	account->activation = true;
}

void Employee::DeActiveAccount(Account* account)
{
	account->activation = false;
	cout << 1;
}

void Employee::DeleteAccount(Customer* customer, Account* account)
{
	vector<Account*> newAccounts;
	for (int i = 0; i < customer->accounts.size(); i++)
	{
		if (customer->accounts[i]->Id == account->Id)
		{
			continue;
		}
		else
		{
			newAccounts.push_back(customer->accounts[i]);
		}
	}
	customer->accounts = newAccounts;
}
